package aThread.bSafe.sync;

/**
 * 使用同步关键字加锁对象的实例方法
 */
public class SyncInstance {
}
