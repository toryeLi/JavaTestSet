package aThread.cThreadLock;

public class ReadWriteLockDemo {
    /**
     *  用来测试IntelliJ IDEA快捷键代码
     */
    public void fb(){
        System.out.println("I am f");
    }
}
